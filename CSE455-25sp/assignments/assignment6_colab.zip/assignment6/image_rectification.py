import numpy as np
from fundamental_matrix import *

def compute_epipole(points1, points2, F):
    """
    COMPUTE_EPIPOLE computes the epipole (right nullspace of F^T) in homogeneous coordinates.

    Args:
        points1 - (N, 3) array of homogeneous points in the first image.
        points2 - (N, 3) array of homogeneous points in the second image.
        F - (3, 3) fundamental matrix such that points2^T * F * points1 = 0.

    Returns:
        epipole - (3,) homogeneous coordinates [x, y, 1] of the epipole in the second image.

    Hints:
        - The epipole is the right null vector of F^T * points2.T.
    """
    ### START YOUR CODE ###

    ### END YOUR CODE ###
    

def compute_matching_homographies(e2, F, im2, points1, points2):
    """
    COMPUTE_MATCHING_HOMOGRAPHIES returns homographies H1 and H2 that rectify a stereo pair.

    Args:
        e2 - (3,) homogeneous coordinates of the epipole in the second image.
        F - (3, 3) fundamental matrix between the two images.
        im2 - Image array of the second image.
        points1 - (N, 3) homogeneous points in the first image.
        points2 - (N, 3) homogeneous points in the second image.

    Returns:
        H1 - (3, 3) homography to rectify the first image.
        H2 - (3, 3) homography to rectify the second image.

    Hints:
        - Follow Hartley & Zisserman's rectification approach.
        - Translate image center to origin, rotate epipole to x-axis, then project to infinity.
        - Estimate affine transform H1 to align transformed points.
    """
    H1 = np.eye(3)
    H2 = np.eye(3)
    ### START YOUR CODE ###

    ### END YOUR CODE ###

    return H1, H2
