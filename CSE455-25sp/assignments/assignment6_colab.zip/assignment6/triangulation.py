import numpy as np
import matplotlib.pyplot as plt

"""
ESTIMATE_INITIAL_RT computes 4 possible relative camera extrinsics [R|T] from an essential matrix.

Args:
    E - (3, 3) Essential matrix

Returns:
    RT - (4, 3, 4) Array of 3x4 camera extrinsics, each representing a possible [R|T] solution

Hints:
    - Use SVD on E.
    - Construct R from U, W, V^T.
    - The four configurations arise from two R and two T choices.
"""
def estimate_initial_RT(E):
    RT = np.zeros((4, 3, 4))
    ### START YOUR CODE ###

    ### END YOUR CODE ###
    return RT


"""
LINEAR_ESTIMATE_3D_POINT triangulates a 3D point from multiple views using the linear method.

Args:
    image_points - (M, 2) 2D points in each image
    camera_matrices - (M, 3, 4) camera projection matrices

Returns:
    point_3d - (3,) Estimated 3D point

Hints:
    - Construct the A matrix from the cross product constraint.
    - Solve Af = 0 via SVD.
"""
def linear_estimate_3d_point(image_points, camera_matrices):
    point_3d = np.zeros(3)
    ### START YOUR CODE ###

    ### END YOUR CODE ###
    return point_3d


"""
REPROJECTION_ERROR computes reprojection error of a 3D point given image measurements.

Args:
    point_3d - (3,) The estimated 3D point
    image_points - (M, 2) Measured 2D points in the images
    camera_matrices - (M, 3, 4) Camera projection matrices

Returns:
    error - (2M,) Reprojection error vector

Hints:
    - Project the 3D point into each view and compare with measured image point.
"""
def reprojection_error(point_3d, image_points, camera_matrices):
    error = np.zeros((2 * image_points.shape[0],))
    ### START YOUR CODE ###

    ### END YOUR CODE ###
    return error


"""
JACOBIAN computes the Jacobian matrix of reprojection error w.r.t. the 3D point.

Args:
    point_3d - (3,) Estimated 3D point
    camera_matrices - (M, 3, 4) Projection matrices

Returns:
    jacobian - (2M, 3) Jacobian matrix
"""
def jacobian(point_3d, camera_matrices):
    jacobian = np.zeros((2 * camera_matrices.shape[0], 3))
    ### START YOUR CODE ###

    ### END YOUR CODE ###
    return jacobian


"""
NONLINEAR_ESTIMATE_3D_POINT refines a 3D point estimate using iterative optimization.

Args:
    image_points - (M, 2) 2D image observations
    camera_matrices - (M, 3, 4) camera projection matrices

Returns:
    point_3d - (3,) Refined 3D point estimate

Hints:
    - Use Gauss-Newton update: P_t+1 = P_t - (JᵗJ)⁻¹ Jᵗ e
    - Initialize with linear triangulation
"""
def nonlinear_estimate_3d_point(image_points, camera_matrices):
    point_3d = np.zeros(3)
    ### START YOUR CODE ###

    ### END YOUR CODE ###
    return point_3d


"""
ESTIMATE_RT_FROM_E selects the correct [R|T] from four possibilities using the positive depth constraint.

Args:
    E - (3, 3) Essential matrix
    image_points - (N, 2, 2) Image point correspondences for N points
    K - (3, 3) Intrinsic matrix

Returns:
    correct_RT - (3, 4) The correct camera extrinsic matrix [R|T]
"""
def estimate_RT_from_E(E, image_points, K):
    correct_RT = np.zeros((3, 4))
    ### START YOUR CODE ###

    ### END YOUR CODE ###
    return correct_RT
