"""
CS131 - Computer Vision: Foundations and Applications
Assignment 4
Author: Donsuk Lee (donlee90@stanford.edu)
Date created: 09/2017
Last modified: 10/9/2020
Python Version: 3.5+
"""

import numpy as np
import random
from scipy.spatial.distance import squareform, pdist, cdist
from skimage.util import img_as_float

### Clustering Methods
def kmeans(features, k, num_iters=100):
    """ Use kmeans algorithm to group features into k clusters.

    K-Means algorithm can be broken down into following steps:
        1. Randomly initialize cluster centers
        2. Assign each point to the closest center
        3. Compute new center of each cluster
        4. Stop if cluster assignments did not change
        5. Go to step 2

    Args:
        features - Array of N features vectors. Each row represents a feature
            vector.
        k - Number of clusters to form.
        num_iters - Maximum number of iterations the algorithm will run.

    Returns:
        assignments - Array representing cluster assignment of each point.
            (e.g. i-th point is assigned to cluster assignments[i])
    """

    N, D = features.shape

    assert N >= k, 'Number of clusters cannot be greater than number of points'

    # Randomly initalize cluster centers
    idxs = np.random.choice(N, size=k, replace=False)
    centers = features[idxs]
    assignments = np.zeros(N, dtype=np.uint32)

    for n in range(num_iters):
        ### YOUR CODE HERE
        # ~~START DELETE~~
        # Step 1: assign each point to the closest center
        new_assignments = np.zeros(N, dtype=np.uint32)
        for j, x in enumerate(features):
            dists = np.sqrt(np.sum((centers - x) ** 2, axis=1))
            new_assignments[j] = np.argmin(dists)

        # Stop if cluster assignments did not change
        if (new_assignments == assignments).all():
            break

        assignments = new_assignments

        # Step 2: compute new mean of each cluster
        for i in range(k):
            centers[i] = np.mean(features[assignments == i], axis=0)
        # ~~END DELETE~~
        ### END YOUR CODE

    return assignments

def kmeans_fast(features, k, num_iters=100):
    """ Use kmeans algorithm to group features into k clusters.

    This function makes use of numpy functions and broadcasting to speed up the
    first part(cluster assignment) of kmeans algorithm.

    Hints
    - You may find cdist (imported from scipy.spatial.distance) and np.argmin useful

    Args:
        features - Array of N features vectors. Each row represents a feature
            vector.
        k - Number of clusters to form.
        num_iters - Maximum number of iterations the algorithm will run.

    Returns:
        assignments - Array representing cluster assignment of each point.
            (e.g. i-th point is assigned to cluster assignments[i])
    """

    N, D = features.shape

    assert N >= k, 'Number of clusters cannot be greater than number of points'

    # Randomly initalize cluster centers
    idxs = np.random.choice(N, size=k, replace=False)
    centers = features[idxs]
    assignments = np.zeros(N, dtype=np.uint32)

    for n in range(num_iters):
        ### YOUR CODE HERE
        # ~~START DELETE~~
        # Step 1: assign each point to the closest center
        #centers = np.repeat(centers[..., np.newaxis], N, axis=2)
        #centers = centers.transpose((2, 1, 0))
        #dists = np.sum((centers - features[..., np.newaxis]) ** 2, axis=1)

        dists = cdist(features, centers)
        new_assignments = np.argmin(dists, axis=1)

        # Stop if cluster assignments did not change
        if (new_assignments == assignments).all():
            break

        assignments = new_assignments

        # Step 2: compute new mean of each cluster
        centers = np.zeros((k, D))
        for i in range(k):
            centers[i] = np.mean(features[assignments == i], axis=0)
        # ^It's also possible to replace this for loop with:
        # > np.add.at(centers, assignments, features)
        # > centers /= np.bincount(assignments)[:, None]

        # ~~END DELETE~~
        ### END YOUR CODE

    return assignments



def hierarchical_clustering(features, k):
    """ Run the hierarchical agglomerative clustering algorithm.

    The algorithm is conceptually simple:

    Assign each point to its own cluster
    While the number of clusters is greater than k:
        Compute the distance between all pairs of clusters
        Merge the pair of clusters that are closest to each other

    We will use Euclidean distance to define distance between clusters.

    Recomputing the centroids of all clusters and the distances between all
    pairs of centroids at each step of the loop would be very slow. Thankfully
    most of the distances and centroids remain the same in successive
    iterations of the outer loop; therefore we can speed up the computation by
    only recomputing the centroid and distances for the new merged cluster.

    Even with this trick, this algorithm will consume a lot of memory and run
    very slowly when clustering large set of points. In practice, you probably
    do not want to use this algorithm to cluster more than 10,000 points.

    Hints
    - You may find pdist (imported from scipy.spatial.distance) useful

    Args:
        features - Array of N features vectors. Each row represents a feature
            vector.
        k - Number of clusters to form.

    Returns:
        assignments - Array representing cluster assignment of each point.
            (e.g. i-th point is assigned to cluster assignments[i])
    """



    N, D = features.shape

    assert N >= k, 'Number of clusters cannot be greater than number of points'

    # Assign each point to its own cluster
    assignments = np.arange(N, dtype=np.uint32)
    centers = np.copy(features)
    n_clusters = N

    # ~~START DELETE NO PASS~~
    # TODO note from @brentyi: this initialization is needed to do an incremental
    # distance update. We need to decide whether to tell students to do this or
    # not and clarify the docstring.

    # Initial distances array
    dists = squareform(pdist(centers))
    np.fill_diagonal(dists, float('inf'))
    assert dists.shape == (N, N)
    # ~~END DELETE NO PASS~~

    while n_clusters > k:
        ### YOUR CODE HERE
        # ~~START DELETE~~

        # Find closest cluster pairs
        i, j = np.sort(np.unravel_index(np.argmin(dists), dists.shape))

        # Delete bigger index, shift assignments
        assignments[assignments == j] = i
        assignments[assignments > j] -= 1

        # Update centers: delete j, recompute i
        centers = np.delete(centers, j, axis=0)
        centers[i] = np.mean(features[assignments == i], axis=0)
        n_clusters -= 1

        # Incremental distance update
        # Note that the speedup here is pretty small: it just brings the
        # overall runtime of each iteration to O(num_clusters^2) instead of
        # O(k * num_clusters^2)
        dists = np.delete(np.delete(dists, j, axis=0), j, axis=1)
        dists[i, :] = np.linalg.norm(centers - centers[i, None, :], axis=1)
        dists[:, i] = dists[i, :]
        dists[i, i] = float('inf')

        ### Simple "inefficient" pdist solution
        ### > This is maybe what we should encourage students to do?
        if False:
            dists = squareform(pdist(centers))
            np.fill_diagonal(dists, float('inf'))

            # Find closest cluster pairs
            i, j = np.sort(np.unravel_index(np.argmin(dists), dists.shape))

            # Delete bigger index, shift assignments
            assignments[assignments == j] = i
            assignments[assignments > j] -= 1

            # Update centers: delete j, recompute i
            centers = np.delete(centers, j, axis=0)
            centers[i] = np.mean(features[assignments == i], axis=0)
            n_clusters -= 1

        ### Old solution (bad?)
        if False:
            # Compute distance between all pairs of cluster centers
            dists = squareform(pdist(centers))
            np.fill_diagonal(dists, float('inf'))

            # Find closest cluster pairs
            i, j = np.unravel_index(np.argmin(dists), dists.shape)

            # Merge two clusters
            new_c = 0
            new_assignments = np.zeros(assignments.shape, dtype=np.uint32)
            for c in range(n_clusters):
                if c != i and c != j:
                    new_assignments[assignments == c] = new_c
                    new_c += 1

            new_assignments[assignments == i] = new_c
            new_assignments[assignments == j] = new_c
            assignments = new_assignments
            n_clusters -= 1

            # Compute new cluster centers
            centers = np.zeros((n_clusters, D))
            for n in range(n_clusters):
                centers[n] = np.mean(features[assignments == n], axis=0)
        # ~~END DELETE~~
        ### END YOUR CODE

    return assignments


### Pixel-Level Features
def color_features(img):
    """ Represents a pixel by its color.

    Args:
        img - array of shape (H, W, C)

    Returns:
        features - array of (H * W, C)
    """
    H, W, C = img.shape
    img = img_as_float(img)
    features = np.zeros((H*W, C))

    ### YOUR CODE HERE
    # ~~START DELETE~~
    features = img_as_float(img).reshape((H * W, C))
    # ~~END DELETE~~
    ### END YOUR CODE

    return features

def color_position_features(img):
    """ Represents a pixel by its color and position.

    Combine pixel's RGB value and xy coordinates into a feature vector.
    i.e. for a pixel of color (r, g, b) located at position (x, y) in the
    image. its feature vector would be (r, g, b, x, y).

    Don't forget to normalize features.

    Hints
    - You may find np.mgrid and np.dstack useful
    - You may use np.mean and np.std

    Args:
        img - array of shape (H, W, C)

    Returns:
        features - array of (H * W, C+2)
    """
    H, W, C = img.shape
    color = img_as_float(img)
    features = np.zeros((H*W, C+2))

    ### YOUR CODE HERE
    # ~~START DELETE~~
    position = np.mgrid[:H, :W].transpose((1, 2, 0))
    features = np.dstack((color, position)).reshape((H * W, -1))

    # Normalize Features
    mu = np.mean(features, axis=0)
    sigma = np.std(features, axis=0)
    features = (features - mu) / sigma
    # ~~END DELETE~~
    ### END YOUR CODE

    return features

def my_features(img):
    """ Implement your own features

    Args:
        img - array of shape (H, W, C)

    Returns:
        features - array of (H * W, C)
    """
    features = None
    ### YOUR CODE HERE
    pass
    ### END YOUR CODE
    return features


### Quantitative Evaluation
def compute_accuracy(mask_gt, mask):
    """ Compute the pixel-wise accuracy of a foreground-background segmentation
        given a ground truth segmentation.

    Args:
        mask_gt - The ground truth foreground-background segmentation. A
            logical of size H x W where mask_gt[y, x] is 1 if and only if
            pixel (y, x) of the original image was part of the foreground.
        mask - The estimated foreground-background segmentation. A logical
            array of the same size and format as mask_gt.

    Returns:
        accuracy - The fraction of pixels where mask_gt and mask agree. A
            bigger number is better, where 1.0 indicates a perfect segmentation.
    """

    accuracy = None
    ### YOUR CODE HERE
    # ~~START DELETE~~
    correct = (mask_gt == mask)
    accuracy = np.sum(correct) / mask.size
    # ~~END DELETE~~
    ### END YOUR CODE

    return accuracy

def evaluate_segmentation(mask_gt, segments):
    """ Compare the estimated segmentation with the ground truth.

    Note that 'mask_gt' is a binary mask, while 'segments' contain k segments.
    This function compares each segment in 'segments' with the ground truth and
    outputs the accuracy of the best segment.

    Args:
        mask_gt - The ground truth foreground-background segmentation. A
            logical of size H x W where mask_gt[y, x] is 1 if and only if
            pixel (y, x) of the original image was part of the foreground.
        segments - An array of the same size as mask_gt. The value of a pixel
            indicates the segment it belongs.

    Returns:
        best_accuracy - Accuracy of the best performing segment.
            0 <= accuracy <= 1, where 1.0 indicates a perfect segmentation.
    """

    num_segments = np.max(segments) + 1
    best_accuracy = 0

    # Compare each segment in 'segments' with the ground truth
    for i in range(num_segments):
        mask = (segments == i).astype(int)
        accuracy = compute_accuracy(mask_gt, mask)
        best_accuracy = max(accuracy, best_accuracy)

    return best_accuracy
